// -- Dossier contenant les formulaires Projet Pro
g_variables["dossier-formulaires-pp"] = "kapc/9Aprojetpro/0formulaires";
// -- Dossier contenant les modèles pour les conseillers Projet Pro
g_variables["dossier-conseillers-modeles-pp"] = "kapc/9Aprojetpro/3conseillers";
// -- Dossier contenant le répertoire de conseillers
g_variables["dossier-repertoire-conseillers-pp"] = "repertoires-conseillers-pp";
// -- Dossier contenant les portfolios des conseillers
g_variables["dossier-portfolios-conseillers-pp"] = "portfolios-conseillers-pp";
// -- Dossier contenant les modèles pour les proxys Projet Pro
g_variables["dossier-proxys-modeles-pp"] = "kapc/9Aprojetpro/6proxys";
// -- Dossier contenant les modèles pour les portfolios étudiants Projet Pro
g_variables["dossier-etudiants-modeles-pp"] = "kapc/9Aprojetpro/8etudiants";